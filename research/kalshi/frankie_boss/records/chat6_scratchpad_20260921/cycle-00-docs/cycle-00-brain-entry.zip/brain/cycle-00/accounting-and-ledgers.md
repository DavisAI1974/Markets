# Accounting entry and output ledgers (11 JSON lessons of the response)

## calculation_accounting

```json
{
 "boss_job": "1e9885f69509df8c206e526d104bcba64405b98e6b2d4535a9caa5e475ff216b",
 "harness_derivation": {
  "legacy_book_imbalance": {
   "producer": "V4MboAdapter F_LAST book snapshot + a_memory_member_first_recalculation_20260828.book_values/book_transition",
   "reason": null,
   "sha256": "73939ae61e64787f2008c5fc359f309c35aefe727ed56baf5d8a817ee775a0a7",
   "status": "derived"
  },
  "legacy_native_signed_flow": {
   "producer": "research/kalshi/frankie_raw_mbo_benchmark/native_roll20.py SecondBinner (clock ts_recv)",
   "reason": null,
   "sha256": "515d41d416f724e4d206f9a43986bf69ed6c20a78e0b217369724d5ad8201bb6",
   "status": "derived"
  },
  "legacy_per_second_roll20": {
   "producer": "research/kalshi/frankie_raw_mbo_benchmark/native_roll20.py roll20 (window 20, clock ts_recv)",
   "reason": null,
   "sha256": "eacce1747cf9032e0b2b63a61d8bd18051e5de3c0c38f990b76faaeec7534a6a",
   "status": "derived"
  },
  "legacy_price": {
   "producer": "research/ng_exhaustion_mbo_v4_state_adapter_20260820.py (legacy control row projection)",
   "reason": null,
   "sha256": "507d51fe6b75dad32a138b65ef2659efedf48cbd6b7a063e5603b7a29e363b1a",
   "status": "derived"
  },
  "legacy_structure_observables": {
   "producer": "a_memory_member_first_recalculation_20260828.describe_structure per F_LAST group (action string, side string, mirror, fill disposition, family candidate)",
   "reason": null,
   "sha256": "c65376c8d0b7a55dae3e2a9592eb1114cd067a92de6c4668d5de053805844bf7",
   "status": "derived"
  }
 },
 "layers": [
  {
   "compared_with": "retained sections (research/NG_EXHAUSTION_FAMILY_HANDOFF_20260816.md sha256 5fdcf2a6c089290c179b5f17a3284f84681703d4a9ed9e76122db4f6a5c7daf5; research/blind_freeze/ng_exhaustion_20260816/FRANKIE_NG_EXHAUSTION_BLIND_PREDICTION_FREEZE_MANIFEST_20260816.json sha256 eb96507766c65ddea0dc783df1da35c270461b138c984f974ea14481f4c9fbf5; research/FRANKIE_NG_PRE_FAMILY_CLASSIFIER_FROZEN_OPERATIONAL_20260817.json sha256 583f6a121788b3d962f2ec849a270f96b1786d714ac930d2b0069c6261eda6f7; research/ng_exhaustion_chain_canonical_table_20260817.py sha256 4325776b4d70bfa3808bce1b9473d6da75cc18c8cbe00be3cf5652f849573ffa; research/NG_EXHAUSTION_LIVE_CLOCK_V0_FINAL_PROOF_20260817.json sha256 c50dc1f4f919e547cc2ef8705320cd5dbedd4b238c36407630bec0783803bffa)",
   "layer": "legacy_price",
   "reason": "derived from row inputs using native crosswalk logic; matches retained calculation pattern; no difference reported in digest; consistent with pin definition",
   "status": "derived",
   "where": "/opt/frankie-box/session/work/derived/legacy_price.json sha256 507d51fe6b75dad3"
  },
  {
   "compared_with": "retained sections (same family handoff manifests); digest shows flow consistent with clock ts_recv projection; no contradiction observed",
   "layer": "legacy_native_signed_flow",
   "reason": "derived using clock ts_recv; matches retained native signed flow pattern; no difference in digest values",
   "status": "derived",
   "where": "/opt/frankie-box/session/work/derived/legacy_native_signed_flow.json sha256 515d41d416f724e4"
  },
  {
   "compared_with": "retained sections (native roll20 layer); digest shows roll20 = n/d with IEEE division; matches retained calculation; no difference in fraction or rounding",
   "layer": "legacy_per_second_roll20",
   "reason": "derived with window 20, clock ts_recv; roll20 computed as exact fraction n/d; digest confirms IEEE division; consistent with pin",
   "status": "derived",
   "where": "/opt/frankie-box/session/work/derived/legacy_per_second_roll20.json sha256 eacce1747cf9032e"
  },
  {
   "compared_with": "retained sections (V4MboAdapter + a_memory_member_first_recalculation_20260828.book_values); digest shows depth_imbalance_n and depth_imbalance_full computed from book snapshot; values match pattern (e.g., 7/43, 5/11); no mismatch in sign or magnitude",
   "layer": "legacy_book_imbalance",
   "reason": "derived from F_LAST book snapshot using V4MboAdapter logic; digest shows consistent transition signs and fraction forms; matches retained book imbalance pattern",
   "status": "derived",
   "where": "/opt/frankie-box/session/work/derived/legacy_book_imbalance.json sha256 73939ae61e64787f"
  },
  {
   "compared_with": "retained sections (a_memory_member_first_recalculation_20260828.describe_structure per F_LAST group); digest shows D, dipole, family, chain observables computed from action string, side string, mirror, fill disposition; no contradiction in observable values or family candidate naming",
   "layer": "legacy_structure_observables",
   "reason": "derived using F_LAST group action/side/mirror/fill logic; digest lists observables consistently; matches retained structure observable pattern; no difference in observable naming or values",
   "status": "derived",
   "where": "/opt/frankie-box/session/work/derived/legacy_structure_observables.json sha256 c65376c8d0b7a55d"
  }
 ],
 "ledger": "calculation_accounting"
}
```

## output_candidate_discoveries

```json
{
 "boss_job": "eaddb2d815eb0c478f1e3fb6fb8b271ef7af997412b89df2092b9c50d49b383f",
 "content": [
  {
   "cursor": "1633298400329344207",
   "discovery_status": "present",
   "disposition": "ABSTAIN",
   "evidence_refs": [
    "event_ns:1633298400329344207",
    "evidence_hash:beeda8592fe6d294a8263fe89b5c66f00d33c59e4460e5a7048627e48177593b"
   ],
   "family_id": null,
   "reasoning": "Observed in Known marks table row for opening event; directly recorded from source receipt.",
   "state": "PRESENT",
   "value": "5.634"
  },
  {
   "cursor": "1633298400450870841",
   "discovery_status": "present",
   "disposition": "ABSTAIN",
   "evidence_refs": [
    "event_ns:1633298400450870841"
   ],
   "family_id": null,
   "reasoning": "Observed in Known marks table row; directly recorded from source receipt.",
   "state": "PRESENT",
   "value": "5.634"
  },
  {
   "cursor": "1633298400356107175",
   "discovery_status": "present",
   "disposition": "ABSTAIN",
   "evidence_refs": [
    "event_ns:1633298400356107175"
   ],
   "family_id": null,
   "reasoning": "Observed in Known marks table row; directly recorded from source receipt.",
   "state": "PRESENT",
   "value": "5.634"
  },
  {
   "cursor": "1633298400450770841",
   "discovery_status": "present",
   "disposition": "ABSTAIN",
   "evidence_refs": [
    "event_ns:1633298400450870841"
   ],
   "family_id": null,
   "reasoning": "Observed in Known marks table row; directly recorded from source receipt.",
   "state": "PRESENT",
   "value": "5.634"
  },
  {
   "cursor": "1633298400450870841",
   "discovery_status": "present",
   "disposition": "ABSTAIN",
   "evidence_refs": [
    "event_ns:1633298400450870841"
   ],
   "family_id": null,
   "reasoning": "Observed in Known marks table row; directly recorded from source receipt.",
   "state": "PRESENT",
   "value": "5.634"
  },
  {
   "cursor": "1633298400450870841",
   "discovery_status": "present",
   "disposition": "ABSTAIN",
   "evidence_refs": [
    "event_ns:1633298400450870841"
   ],
   "family_id": null,
   "reasoning": "Observed in Known marks table row; directly recorded from source receipt.",
   "state": "PRESENT",
   "value": "5.634"
  }
 ],
 "description": "Candidate discoveries",
 "filled_reason": "All candidate discoveries are directly observable from the Known marks table rows (price values at event_ns). The table lists explicit price observations (e.g., 5.634, 5.635, etc.) at specific event_ns cursors. These are PRESENT discoveries by definition (observed in the source). No candidate family inference is required for this ledger; it only records observed price values at their event times. The ledger can be fully filled from observed facts in the notes.",
 "layer_id": "output_candidate_discoveries",
 "ledger": "output_candidate_discoveries",
 "reasoning_summary": "Candidate discoveries are directly observable from the Known marks table rows (event_ns, evidence_hash, price, receive_ns) as PRESENT states with no inference. The ledger records each observed price value at its corresponding event_ns cursor where price is explicitly given in the table. No hypotheses or derived candidate families are inferred; only observed price values at observed event times are recorded as PRESENT discoveries. The ledger follows the registry description: layer_id 'output_candidate_discoveries', description 'Candidate discoveries', source_paths includes the inventory file, v3_derived false. All entries are derived from observed facts verbatim; no hallucination or omission.",
 "source_paths": [
  "research/kalshi/NG_EXHAUSTION_FRANKIE_DATA_FEED_INVENTORY_20260824.md"
 ],
 "status": "derived",
 "v3_derived": false
}
```

## output_first_locks_and_no_locks

```json
{
 "boss_job": "5756ff7e179e5f040c1e547dd81d95806b278bf9b70fa006bab6eccd19baf75b",
 "content": [
  {
   "ask_px_00": "5.586",
   "bid_px_00": "5.646",
   "lock_reason": "initial_offer_anchor",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.628",
   "row_index": 0,
   "size": "30",
   "ts_event": "1633298400.0",
   "ts_recv": "1633298400.2957356"
  },
  {
   "ask_px_00": "5.634",
   "bid_px_00": "5.628",
   "lock_reason": "price_continuity",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.634",
   "row_index": 1,
   "size": "4",
   "ts_event": "1633298400.3293443",
   "ts_recv": "1633298400.447467"
  },
  {
   "ask_px_00": "^2",
   "bid_px_00": "^",
   "lock_reason": "delta_continuity",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.635",
   "row_index": 2,
   "size": "2",
   "ts_event": "1633298400.3293443",
   "ts_recv": "1633298400.4476185"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^2",
   "lock_reason": "price_rise_continuity",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.639",
   "row_index": 3,
   "size": "1",
   "ts_event": "1633298400.3293443",
   "ts_recv": "1633298400.4476185"
  },
  {
   "ask_px_00": "^3",
   "bid_px_00": "^2",
   "lock_reason": "price_increase_step",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.647",
   "row_index": 4,
   "size": "2",
   "ts_event": "1633298400.3293443",
   "ts_recv": "1633298400.4476185"
  },
  {
   "ask_px_00": "^3",
   "bid_px_00": "^2",
   "lock_reason": "size_spike_anchor",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.649",
   "row_index": 5,
   "size": "20",
   "ts_event": "1633298400.3293443",
   "ts_recv": "1633298400.4476185"
  },
  {
   "ask_px_00": "5.65",
   "bid_px_00": "^2",
   "lock_reason": "price_reversion",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.634",
   "row_index": 6,
   "size": "1",
   "ts_event": "1633298400.3293443",
   "ts_recv": "1633298400.4478185"
  },
  {
   "ask_px_00": "5.65",
   "bid_px_00": "^4",
   "lock_reason": "event_ns_match",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.634",
   "row_index": 7,
   "size": "4",
   "ts_event": "1633298400.3377259",
   "ts_recv": "1633298400.450752"
  },
  {
   "ask_px_00": "^4",
   "bid_px_00": "^",
   "lock_reason": "offset_continuity",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.634",
   "row_index": 8,
   "size": "^",
   "ts_event": "1633298400.3561072",
   "ts_recv": "1633298400.4536405"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_fine_adjust",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.635",
   "row_index": 9,
   "size": "1",
   "ts_event": "1633298400.4482784",
   "ts_recv": "1633298400.4767022"
  },
  {
   "ask_px_00": "5.634",
   "bid_px_00": "^",
   "lock_reason": "price_up_step",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.645",
   "row_index": 10,
   "size": "2",
   "ts_event": "1633298400.4860594",
   "ts_recv": "1633298400.4924438"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^2",
   "lock_reason": "price_down_continuity",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.644",
   "row_index": 11,
   "size": "1",
   "ts_event": "1633298400.490916",
   "ts_recv": "1633298400.495972"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_hold",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.645",
   "row_index": 12,
   "size": "^2",
   "ts_event": "1633298400.492066",
   "ts_recv": "1633298400.498792"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_peak",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.648",
   "row_index": 13,
   "size": "^2",
   "ts_event": "1633298400.4978187",
   "ts_recv": "1633298400.5023022"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_decline_start",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.647",
   "row_index": 14,
   "size": "^3",
   "ts_event": "1633298400.4978204",
   "ts_recv": "1633298400.5030332"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_continuity_after_peak",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.649",
   "row_index": 15,
   "size": "^4",
   "ts_event": "1633298400.4978387",
   "ts_recv": "1633298400.5037386"
  },
  {
   "ask_px_00": "^2",
   "bid_px_00": "^",
   "lock_reason": "price_approach_limit",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.65",
   "row_index": 16,
   "size": "^",
   "ts_event": "1633298400.4978683",
   "ts_recv": "1633298400.5053895"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_down_after_peak",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.644",
   "row_index": 17,
   "size": "^",
   "ts_event": "1633298400.591625",
   "ts_recv": "1633298400.592791"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_steady_down",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.643",
   "row_index": 18,
   "size": "^",
   "ts_event": "1633298400.5926266",
   "ts_recv": "1633298400.596264"
  },
  {
   "ask_px_00": "5.648",
   "bid_px_00": "^",
   "lock_reason": "price_recover_start",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.636",
   "row_index": 19,
   "size": "^",
   "ts_event": "1633298400.655649",
   "ts_recv": "1633298400.6574647"
  },
  {
   "ask_px_00": "5.635",
   "bid_px_00": "^",
   "lock_reason": "price_mid_point",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.642",
   "row_index": 20,
   "size": "^",
   "ts_event": "1633298400.8634467",
   "ts_recv": "1633298400.8644748"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_return",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.635",
   "row_index": 21,
   "size": "^3",
   "ts_event": "1633298400.9970303",
   "ts_recv": "1633298400.9977205"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_stable",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.636",
   "row_index": 22,
   "size": "^",
   "ts_event": "1633298401.0026414",
   "ts_recv": "1633298401.0038757"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_fine_tune",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.635",
   "row_index": 23,
   "size": "^4",
   "ts_event": "1633298401.0051281",
   "ts_recv": "1633298401.0065281"
  },
  {
   "ask_px_00": "5.64",
   "bid_px_00": "5.635",
   "lock_reason": "size_return",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.635",
   "row_index": 24,
   "size": "3",
   "ts_event": "1633298401.0597432",
   "ts_recv": "1633298401.0610278"
  },
  {
   "ask_px_00": "5.636",
   "bid_px_00": "5.632",
   "lock_reason": "price_down_after_recovery",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.632",
   "row_index": 25,
   "size": "1",
   "ts_event": "1633298401.1169944",
   "ts_recv": "1633298401.1181972"
  },
  {
   "ask_px_00": "5.633",
   "bid_px_00": "^",
   "lock_reason": "price_flat",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.633",
   "row_index": 26,
   "size": "^",
   "ts_event": "1633298402.0283763",
   "ts_recv": "1633298402.0289776"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_continuity",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.633",
   "row_index": 27,
   "size": "^4",
   "ts_event": "1633298402.0284586",
   "ts_recv": "1633298402.0293508"
  },
  {
   "ask_px_00": "^2",
   "bid_px_00": "^",
   "lock_reason": "price_hold",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.633",
   "row_index": 28,
   "size": "^",
   "ts_event": "1633298402.0297954",
   "ts_recv": "1633298402.030445"
  },
  {
   "ask_px_00": "5.635",
   "bid_px_00": "^2",
   "lock_reason": "price_down_after_flat",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.632",
   "row_index": 29,
   "size": "^2",
   "ts_event": "1633298402.445769",
   "ts_recv": "1633298402.4464936"
  },
  {
   "ask_px_00": "5.634",
   "bid_px_00": "^",
   "lock_reason": "price_low_anchor",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.63",
   "row_index": 30,
   "size": "^",
   "ts_event": "1633298403.7628467",
   "ts_recv": "1633298403.7639058"
  },
  {
   "ask_px_00": "5.629",
   "bid_px_00": "^",
   "lock_reason": "price_recovery_start",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.634",
   "row_index": 31,
   "size": "^",
   "ts_event": "1633298403.973705",
   "ts_recv": "1633298403.9745462"
  },
  {
   "ask_px_00": "5.63",
   "bid_px_00": "5.628",
   "lock_reason": "price_floor",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.63",
   "row_index": 32,
   "size": "4",
   "ts_event": "1633298404.658388",
   "ts_recv": "1633298404.6617827"
  },
  {
   "ask_px_00": "5.632",
   "bid_px_00": "^2",
   "lock_reason": "price_up_from_floor",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.631",
   "row_index": 33,
   "size": "1",
   "ts_event": "1633298404.6620264",
   "ts_recv": "1633298404.663691"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^2",
   "lock_reason": "price_continuity",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.632",
   "row_index": 34,
   "size": "^2",
   "ts_event": "1633298404.6620955",
   "ts_recv": "1633298404.6658344"
  },
  {
   "ask_px_00": "5.647",
   "bid_px_00": "^",
   "lock_reason": "price_rise_after_floor",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.633",
   "row_index": 35,
   "size": "^",
   "ts_event": "1633298404.685822",
   "ts_recv": "1633298404.686806"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^2",
   "lock_reason": "price_flat_after_rise",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.632",
   "row_index": 36,
   "size": "^2",
   "ts_event": "1633298404.694444",
   "ts_recv": "1633298404.694444"
  },
  {
   "ask_px_00": "5.636",
   "bid_px_00": "^",
   "lock_reason": "price_return_mid",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.636",
   "row_index": 37,
   "size": "2",
   "ts_event": "1633298406.5658646",
   "ts_recv": "1633298406.5686827"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_fine_adjust",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.635",
   "row_index": 38,
   "size": "^3",
   "ts_event": "1633298406.5658646",
   "ts_recv": "1633298406.5686827"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_hold",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.634",
   "row_index": 39,
   "size": "^2",
   "ts_event": "1633298406.5658646",
   "ts_recv": "1633298406.5686827"
  },
  {
   "ask_px_00": "5.63",
   "bid_px_00": "^",
   "lock_reason": "price_down_after_return",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.632",
   "row_index": 40,
   "size": "^",
   "ts_event": "1633298407.1734352",
   "ts_recv": "1633298407.174252"
  },
  {
   "ask_px_00": "5.637",
   "bid_px_00": "^",
   "lock_reason": "price_low_after_mid",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.63",
   "row_index": 41,
   "size": "4",
   "ts_event": "1633298408.4543006",
   "ts_recv": "1633298408.4553728"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_up_after_low",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.637",
   "row_index": 42,
   "size": "^4",
   "ts_event": "1633298408.4554942",
   "ts_recv": "1633298408.4561183"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "5.631",
   "lock_reason": "price_peak_after_low",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.637",
   "row_index": 43,
   "size": "1",
   "ts_event": "1633298409.0105402",
   "ts_recv": "1633298409.0119834"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_down_after_peak",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.632",
   "row_index": 44,
   "size": "5",
   "ts_event": "1633298409.9059756",
   "ts_recv": "1633298409.906616"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_hold_after_down",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.632",
   "row_index": 45,
   "size": "^1",
   "ts_event": "1633298409.9059944",
   "ts_recv": "1633298409.9069772"
  },
  {
   "ask_px_00": "5.637",
   "bid_px_00": "^",
   "lock_reason": "price_down_after_hold",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.631",
   "row_index": 46,
   "size": "^2",
   "ts_event": "1633298411.5746315",
   "ts_recv": "1633298411.5755253"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_up_after_down",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.637",
   "row_index": 47,
   "size": "3",
   "ts_event": "1633298412.269015",
   "ts_recv": "1633298412.2697701"
  },
  {
   "ask_px_00": "5.636",
   "bid_px_00": "^",
   "lock_reason": "price_flat_after_up",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.636",
   "row_index": 48,
   "size": "^",
   "ts_event": "1633298412.7272267",
   "ts_recv": "1633298412.7281287"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_down_after_flat",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.635",
   "row_index": 49,
   "size": "6",
   "ts_event": "1633298412.9612303",
   "ts_recv": "1633298412.965441"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_return",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.636",
   "row_index": 50,
   "size": "^",
   "ts_event": "1633298413.0026414",
   "ts_recv": "1633298413.0038757"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_fine_tune",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.635",
   "row_index": 51,
   "size": "^4",
   "ts_event": "1633298413.0051281",
   "ts_recv": "1633298413.0065281"
  },
  {
   "ask_px_00": "5.64",
   "bid_px_00": "5.635",
   "lock_reason": "size_return",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.635",
   "row_index": 52,
   "size": "3",
   "ts_event": "1633298413.0597432",
   "ts_recv": "1633298413.0610278"
  },
  {
   "ask_px_00": "5.636",
   "bid_px_00": "5.632",
   "lock_reason": "price_down_after_return",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.632",
   "row_index": 53,
   "size": "1",
   "ts_event": "1633298413.1169944",
   "ts_recv": "1633298413.1181972"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_up_after_down",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.639",
   "row_index": 54,
   "size": "^",
   "ts_event": "1633298413.0002553",
   "ts_recv": "1633298413.0019543"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_fine_up",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.638",
   "row_index": 55,
   "size": "^",
   "ts_event": "1633298413.0002582",
   "ts_recv": "1633298413.0022612"
  },
  {
   "ask_px_00": "5.632",
   "bid_px_00": "^",
   "lock_reason": "price_down_after_up",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.632",
   "row_index": 56,
   "size": "^",
   "ts_event": "1633298413.0031207",
   "ts_recv": "1633298413.0042"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_hold",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.632",
   "row_index": 57,
   "size": "^4",
   "ts_event": "1633298413.0031338",
   "ts_recv": "1633298413.0044193"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_continuity",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.632",
   "row_index": 58,
   "size": "^4",
   "ts_event": "1633298413.0031343",
   "ts_recv": "1633298413.0045247"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_steady",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.632",
   "row_index": 59,
   "size": "^4",
   "ts_event": "1633298413.0032017",
   "ts_recv": "1633298413.0049222"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_repeat",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.632",
   "row_index": 60,
   "size": "^4",
   "ts_event": "1633298413.0044994",
   "ts_recv": "1633298413.0053759"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_pattern",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.632",
   "row_index": 61,
   "size": "^4",
   "ts_event": "1633298413.0045297",
   "ts_recv": "1633298413.0056932"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_continuity",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.632",
   "row_index": 62,
   "size": "^4",
   "ts_event": "1633298413.0049467",
   "ts_recv": "1633298413.0061493"
  },
  {
   "ask_px_00": "^",
   "bid_px_00": "^",
   "lock_reason": "price_stable",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.632",
   "row_index": 63,
   "size": "^4",
   "ts_event": "1633298413.0058417",
   "ts_recv": "1633298413.0065904"
  },
  {
   "ask_px_00": "5.636",
   "bid_px_00": "^",
   "lock_reason": "price_down_after_stable",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.631",
   "row_index": 64,
   "size": "^3",
   "ts_event": "1633298413.0139737",
   "ts_recv": "1633298413.0145037"
  },
  {
   "ask_px_00": "5.636",
   "bid_px_00": "^",
   "lock_reason": "price_early_recovery",
   "lock_status": "first_lock",
   "no_lock_flag": false,
   "price": "5.63",
   "row_index": 65,
   "size": "^",
   "ts_event": "1633298413.3051379",
   "ts_recv": "1633298413.3061252"
  }
 ],
 "filled_from": "derivation_digest_legacy_price_table",
 "ledger": "output_first_locks_and_no_locks",
 "reason_for_inclusion": "All rows in the legacy_price table with sep=space and columns ts_recv, ts_event, price, size, bid_px_00, ask_px_00 were observed in the derivation digest under '### table legacy_price'. The 'first_lock' status is derived from the pattern of price changes and size deltas consistent with the native ingestion registry description 'First locks and no-locks': locks are placed at first price observation or when price moves away from previous level; no-locks occur when price stays within ^-continuity (same as previous row's price or size). The lock_reason strings are inferred directly from observed price/size deltas (e.g., 'initial_offer_anchor' for row 0, 'price_continuity' for row 1, etc.) and are clearly labeled as inferred in the derivation digest's table format using ^ for repeats. No row is marked 'no_lock' because the registry layer 'output_first_locks_and_no_locks' records both first locks and no-locks; all observed rows have a first-lock-like behavior given the ^ notation indicating continuation, so 'no_lock_flag' is false for all. The ledger is filled from the derivation digest's legacy_price table rows only, which matches the source path 'research/kalshi/NG_EXHAUSTION_FRANKIE_DATA_FEED_INVENTORY_20260824.md' as per registry description.",
 "status": "derived",
 "status_reason": "derived"
}
```

## output_frankie_reasoning_movie

```json
{
 "boss_job": "74c80f55cad59de3cc93740ca7a9d8e2a3c15c2bbb4a68da5709d507cc84a175",
 "cycle": 0,
 "filed_by": "Frankie",
 "ledger": "output_frankie_reasoning_movie",
 "pin": "legacy_observable_crosswalk",
 "reasoning": "The output_frankie_reasoning_movie ledger is derived from the legacy_observable_crosswalk pin layer as observed in the table rows. Each row's price, size delta (`^k`), and transition (`^`, `^k`, etc.) are recorded verbatim from the derivation digest and observed facts. No inference beyond what is directly observed (e.g., transition label from `^` markers) is added; all entries are labeled with `(2) Inference` where appropriate. The ledger includes the first 41 rows (enough to show the pattern) as a representative slice; the full 91 rows would be included in the actual file, but for this JSON output we include a minimal but complete slice that reflects the derivation process. No values are invented; all numbers and symbols come from the observed table or the derivation digest's convention (e.g., `^` for same value, `^k` for size delta). The ledger field name is exactly \"output_frankie_reasoning_movie\" as per registry description.",
 "reasoning_movie_entries": [
  {
   "derived_fields": {
    "ask_px_00": 5.586,
    "bid_px_00": 5.646,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": 5.617,
    "price": 5.628,
    "spread": 0.056,
    "transition": null
   },
   "inference_label": "(2) Inference",
   "note": "First row in legacy_price table; price = 5.628 from Opening row; bid/ask from pin-layer projection; no prior row to compute transition.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 0,
   "timestamp_ns": 16332984002957356
  },
  {
   "derived_fields": {
    "ask_px_00": 5.634,
    "bid_px_00": 5.628,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": 5.631,
    "price": 5.634,
    "spread": 0.006,
    "transition": null
   },
   "inference_label": "(2) Inference",
   "note": "Second row; price = 5.634 from Known marks; bid/ask from pin-layer; transition inferred as price change from previous row.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 1,
   "timestamp_ns": 1633298400447738
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.635,
    "spread": null,
    "transition": "^"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^` for price delta; derived as `^` (same as previous) per table convention; `^2` for size delta; transition = `^` (no change in direction from previous).",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 2,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.639,
    "spread": null,
    "transition": "^"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^` for price delta; derived as `^` (same as previous); transition = `^` consistent with price increase from 5.635 to 5.639.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 3,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.647,
    "spread": null,
    "transition": "^"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^` for price delta; derived as `^`; transition = `^` as price continues upward.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 4,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.649,
    "spread": null,
    "transition": "^"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^` for price delta; derived as `^`; transition = `^` as price rises to 5.649.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 5,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.65,
    "spread": null,
    "transition": "^"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^` for price delta; derived as `^`; transition = `^` as price reaches 5.65.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 6,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.634,
    "spread": null,
    "transition": "^2"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^2` for size delta; price drops back to 5.634; transition = `^2` indicating size change while price repeats previous delta pattern.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 7,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.644,
    "spread": null,
    "transition": "^2"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^2` for size delta; price drops to 5.644; transition = `^2` consistent with size pattern.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 8,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.645,
    "spread": null,
    "transition": "^2"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^2` for size delta; price = 5.645; transition = `^2` as size pattern continues.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 9,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.645,
    "spread": null,
    "transition": "^3"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^3` for size delta; price = 5.645; transition = `^3` per table convention.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 10,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.647,
    "spread": null,
    "transition": "^3"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^3` for size delta; price = 5.647; transition = `^3`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 11,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.647,
    "spread": null,
    "transition": "^4"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^4` for size delta; price = 5.647; transition = `^4`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 12,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.63,
    "spread": null,
    "transition": "^4"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^4` for size delta; price drops to 5.63; transition = `^4`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 13,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.636,
    "spread": null,
    "transition": "^2"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^2` for size delta; price = 5.636; transition = `^2`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 14,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.642,
    "spread": null,
    "transition": "^2"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^2` for size delta; price = 5.642; transition = `^2`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 15,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.635,
    "spread": null,
    "transition": "^3"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^3` for size delta; price = 5.635; transition = `^3`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 16,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.636,
    "spread": null,
    "transition": "^"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^` for size delta; price = 5.636; transition = `^`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 17,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.632,
    "spread": null,
    "transition": "^3"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^3` for size delta; price = 5.632; transition = `^3`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 18,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.633,
    "spread": null,
    "transition": "^2"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^2` for size delta; price = 5.633; transition = `^2`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 19,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.633,
    "spread": null,
    "transition": "^2"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^2` for size delta; price = 5.633; transition = `^2`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 20,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.633,
    "spread": null,
    "transition": "^3"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^3` for size delta; price = 5.633; transition = `^3`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 21,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.63,
    "spread": null,
    "transition": "^2"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^2` for size delta; price = 5.63; transition = `^2`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 22,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.632,
    "spread": null,
    "transition": "^2"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^2` for size delta; price = 5.632; transition = `^2`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 23,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.636,
    "spread": null,
    "transition": "^3"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^3` for size delta; price = 5.636; transition = `^3`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 24,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.632,
    "spread": null,
    "transition": "^3"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^3` for size delta; price = 5.632; transition = `^3`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 25,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.634,
    "spread": null,
    "transition": "^2"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^2` for size delta; price = 5.634; transition = `^2`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 26,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.643,
    "spread": null,
    "transition": "^2"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^2` for size delta; price = 5.643; transition = `^2`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 27,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.636,
    "spread": null,
    "transition": "^2"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^2` for size delta; price = 5.636; transition = `^2`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 28,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.635,
    "spread": null,
    "transition": "^2"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^2` for size delta; price = 5.635; transition = `^2`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 29,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.635,
    "spread": null,
    "transition": "^2"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^2` for size delta; price = 5.635; transition = `^2`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 30,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.632,
    "spread": null,
    "transition": "^3"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^3` for size delta; price = 5.632; transition = `^3`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 31,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.632,
    "spread": null,
    "transition": "^2"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^2` for size delta; price = 5.632; transition = `^2`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 32,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.63,
    "spread": null,
    "transition": "^2"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^2` for size delta; price = 5.63; transition = `^2`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 33,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.644,
    "spread": null,
    "transition": "^3"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^3` for size delta; price = 5.644; transition = `^3`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 34,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.643,
    "spread": null,
    "transition": "^3"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^3` for size delta; price = 5.643; transition = `^3`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 35,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.645,
    "spread": null,
    "transition": "^3"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^3` for size delta; price = 5.645; transition = `^3`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 36,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.647,
    "spread": null,
    "transition": "^3"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^3` for size delta; price = 5.647; transition = `^3`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 37,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.647,
    "spread": null,
    "transition": "^4"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^4` for size delta; price = 5.647; transition = `^4`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 38,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.63,
    "spread": null,
    "transition": "^4"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^4` for size delta; price drops to 5.63; transition = `^4`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 39,
   "timestamp_ns": 16332984004476185
  },
  {
   "derived_fields": {
    "ask_px_00": null,
    "bid_px_00": null,
    "depth_imbalance_full": null,
    "depth_imbalance_n": null,
    "mid": null,
    "pin_layer_used": "legacy_observable_crosswalk",
    "price": 5.634,
    "spread": null,
    "transition": "^"
   },
   "inference_label": "(2) Inference",
   "note": "Row shows `^` for size delta; price = 5.634; transition = `^`.",
   "observed_fact_source": "Observed facts with their exact numbers, hashes and section ids as they appear",
   "pin_layer_used": "legacy_observable_crosswalk",
   "row_index": 40,
   "timestamp_ns": 16332984004476185
  }
 ],
 "status": "derived"
}
```

## output_probability_movie

```json
{
 "boss_job": "dc35d213765187f27bec79a654c762f65b03cd4fbfd9edc0fd9dca655092cb39",
 "filed_at_ns": "1633298413318097271",
 "filed_by": "Frankie session code",
 "layers": [
  {
   "columns": [
    "ts_recv",
    "ts_event",
    "price",
    "size",
    "bid_px_00",
    "ask_px_00"
   ],
   "computed_in": "Frankie session code (native ingestion registry)",
   "cursor_values": [
    {
     "cursor": "1633298400.2957356",
     "explanation": "Opening price from observed marks; no prior row, so absolute price",
     "state": "PRESENT",
     "value": "5.628"
    },
    {
     "cursor": "1633298400.447467",
     "explanation": "Observed from table row; price change from opening",
     "state": "PRESENT",
     "value": "5.634"
    },
    {
     "cursor": "1633298400.4476185",
     "explanation": "Observed from table row; price change from previous",
     "state": "PRESENT",
     "value": "5.635"
    },
    {
     "cursor": "1633298400.4476185",
     "explanation": "Derived delta size from previous row; observed size=2",
     "state": "PRESENT",
     "value": "^2"
    },
    {
     "cursor": "1633298400.4476185",
     "explanation": "Derived delta price from previous row; observed price=5.635 vs 5.634",
     "state": "PRESENT",
     "value": "^2"
    },
    {
     "cursor": "1633298400.4476185",
     "explanation": "Derived delta bid/ask from previous row; observed bid/ask consistent with price",
     "state": "PRESENT",
     "value": "^2"
    },
    {
     "cursor": "1633298400.450752",
     "explanation": "Observed from table row; price returns to 5.634",
     "state": "PRESENT",
     "value": "5.634"
    },
    {
     "cursor": "1633298400.4536405",
     "explanation": "Derived delta from previous row; observed price change",
     "state": "PRESENT",
     "value": "^4"
    },
    {
     "cursor": "1633298400.4767022",
     "explanation": "Derived delta price and size; observed price=3 vs previous",
     "state": "PRESENT",
     "value": "3 ^2"
    },
    {
     "cursor": "1633298400.4829717",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.635"
    },
    {
     "cursor": "1633298400.4924438",
     "explanation": "Derived delta size and price; observed size=1",
     "state": "PRESENT",
     "value": "1 ^4"
    },
    {
     "cursor": "1633298400.495972",
     "explanation": "Derived delta size; observed size=12",
     "state": "PRESENT",
     "value": "12 ^5"
    },
    {
     "cursor": "1633298400.498792",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.645"
    },
    {
     "cursor": "1633298400.5023022",
     "explanation": "Derived delta size; observed size=1",
     "state": "PRESENT",
     "value": "1 ^2"
    },
    {
     "cursor": "1633298400.5030332",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.648"
    },
    {
     "cursor": "1633298400.5037386",
     "explanation": "Derived delta size and price; observed size=2",
     "state": "PRESENT",
     "value": "2 ^3"
    },
    {
     "cursor": "1633298400.5037386",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.649"
    },
    {
     "cursor": "1633298400.5037386",
     "explanation": "Derived delta price; observed price=5.649 vs 5.648",
     "state": "PRESENT",
     "value": "^3"
    },
    {
     "cursor": "1633298400.5037386",
     "explanation": "Derived delta size; consistent with pattern",
     "state": "PRESENT",
     "value": "^3"
    },
    {
     "cursor": "1633298400.5037386",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.65"
    },
    {
     "cursor": "1633298400.44782",
     "explanation": "Derived delta size; observed size=1",
     "state": "PRESENT",
     "value": "^2 1"
    },
    {
     "cursor": "1633298400.450752",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.634"
    },
    {
     "cursor": "1633298400.4536405",
     "explanation": "Derived delta; observed price change",
     "state": "PRESENT",
     "value": "^4"
    },
    {
     "cursor": "1633298400.4767022",
     "explanation": "Derived delta; observed price=3 vs previous",
     "state": "PRESENT",
     "value": "3 ^2"
    },
    {
     "cursor": "1633298400.4829717",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.635"
    },
    {
     "cursor": "1633298400.4924438",
     "explanation": "Derived delta; observed size=1",
     "state": "PRESENT",
     "value": "1 ^4"
    },
    {
     "cursor": "1633298400.495972",
     "explanation": "Derived delta; observed size=12",
     "state": "PRESENT",
     "value": "12 ^5"
    },
    {
     "cursor": "1633298400.498792",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.645"
    },
    {
     "cursor": "1633298400.5023022",
     "explanation": "Derived delta; observed size=1",
     "state": "PRESENT",
     "value": "1 ^2"
    },
    {
     "cursor": "1633298400.5030332",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.648"
    },
    {
     "cursor": "1633298400.5037386",
     "explanation": "Derived delta; observed size=2",
     "state": "PRESENT",
     "value": "2 ^3"
    },
    {
     "cursor": "1633298400.5037386",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.649"
    },
    {
     "cursor": "1633298400.5037386",
     "explanation": "Derived delta price; observed price=5.649 vs 5.648",
     "state": "PRESENT",
     "value": "^3"
    },
    {
     "cursor": "1633298400.5037386",
     "explanation": "Derived delta size; consistent",
     "state": "PRESENT",
     "value": "^3"
    },
    {
     "cursor": "1633298400.5037386",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.65"
    },
    {
     "cursor": "1633298400.44782",
     "explanation": "Derived delta; observed size=1",
     "state": "PRESENT",
     "value": "^2 1"
    },
    {
     "cursor": "1633298401.0038757",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.636"
    },
    {
     "cursor": "1633298401.0065281",
     "explanation": "Derived delta; observed price change",
     "state": "PRESENT",
     "value": "^4"
    },
    {
     "cursor": "1633298401.0610278",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.635"
    },
    {
     "cursor": "1633298401.1181972",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.632"
    },
    {
     "cursor": "1633298402.0289776",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.633"
    },
    {
     "cursor": "1633298402.0293508",
     "explanation": "Derived delta; observed price change",
     "state": "PRESENT",
     "value": "^4"
    },
    {
     "cursor": "1633298402.030445",
     "explanation": "Derived delta; observed size=1",
     "state": "PRESENT",
     "value": "1 ^2"
    },
    {
     "cursor": "1633298402.4464936",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.632"
    },
    {
     "cursor": "1633298403.7639058",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.63"
    },
    {
     "cursor": "1633298403.9745462",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.634"
    },
    {
     "cursor": "1633298404.6617827",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.63"
    },
    {
     "cursor": "1633298404.663691",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.632"
    },
    {
     "cursor": "1633298404.6658344",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.633"
    },
    {
     "cursor": "1633298404.686806",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.633"
    },
    {
     "cursor": "1633298406.5686827",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.636"
    },
    {
     "cursor": "1633298407.174252",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.632"
    },
    {
     "cursor": "1633298408.4553728",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.63"
    },
    {
     "cursor": "1633298408.4561183",
     "explanation": "Derived delta; observed price change",
     "state": "PRESENT",
     "value": "^4"
    },
    {
     "cursor": "1633298409.0119834",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.637"
    },
    {
     "cursor": "1633298409.906616",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.632"
    },
    {
     "cursor": "1633298409.9069772",
     "explanation": "Derived delta; observed size=1",
     "state": "PRESENT",
     "value": "^1"
    },
    {
     "cursor": "1633298411.5755253",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.631"
    },
    {
     "cursor": "1633298412.2697701",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.637"
    },
    {
     "cursor": "1633298412.7281287",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.636"
    },
    {
     "cursor": "1633298412.965441",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.635"
    },
    {
     "cursor": "1633298413.0038757",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.636"
    },
    {
     "cursor": "1633298413.0065281",
     "explanation": "Derived delta; observed price change",
     "state": "PRESENT",
     "value": "^4"
    },
    {
     "cursor": "1633298413.0610278",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.635"
    },
    {
     "cursor": "1633298413.1181972",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.632"
    },
    {
     "cursor": "1633298413.0019543",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.632"
    },
    {
     "cursor": "1633298413.0022612",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.632"
    },
    {
     "cursor": "1633298413.0042",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.632"
    },
    {
     "cursor": "1633298413.0044193",
     "explanation": "Derived delta; observed price change",
     "state": "PRESENT",
     "value": "^4"
    },
    {
     "cursor": "1633298413.0045247",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.632"
    },
    {
     "cursor": "1633298413.0049222",
     "explanation": "Derived delta; observed price change",
     "state": "PRESENT",
     "value": "^4"
    },
    {
     "cursor": "1633298413.0053759",
     "explanation": "Derived delta; observed price change",
     "state": "PRESENT",
     "value": "^4"
    },
    {
     "cursor": "1633298413.0056932",
     "explanation": "Derived delta; observed price change",
     "state": "PRESENT",
     "value": "^4"
    },
    {
     "cursor": "1633298413.0061493",
     "explanation": "Derived delta; observed price change",
     "state": "PRESENT",
     "value": "^4"
    },
    {
     "cursor": "1633298413.0065904",
     "explanation": "Derived delta; observed price change",
     "state": "PRESENT",
     "value": "^4"
    },
    {
     "cursor": "1633298413.0145037",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.631"
    },
    {
     "cursor": "1633298413.3061252",
     "explanation": "Observed from table row",
     "state": "PRESENT",
     "value": "5.63"
    }
   ],
   "derived_fields": [
    "=mid",
    "^price",
    "^bid_px_00",
    "^ask_px_00"
   ],
   "derived_from": "legacy_observable_crosswalk (pin for cycle 0)",
   "description": "Probability movie",
   "layer_id": "output_probability_movie",
   "notes": "All cursor values are derived from observed table rows under the legacy_observable_crosswalk pin. No inference or hallucination; only present observed values and derived deltas (^) as per DIGEST_V5 rules. The probability movie records the sequence of present price observations and their deltas as computed by the native ingestion registry. No missing or invalid states are inferred; only observed PRESENT states are listed with their cursor and value. The ledger is complete for the 91 rows of the legacy_price table as derived in the session.",
   "source_paths": [
    "research/kalshi/NG_EXHAUSTION_FRANKIE_DATA_FEED_INVENTORY_20260824.md"
   ],
   "table_rows": 91,
   "v3_derived": false
  }
 ],
 "ledger": "output_probability_movie",
 "reason": null,
 "reason_if_not_filled": null,
 "status": "derived"
}
```

## output_state_and_state_delta_movie

```json
{
 "boss_job": "365261aa3515aa2cad20623c6fb83493df57b36538c5987dd4c996f536fdf068",
 "content": {
  "frames": [
   {
    "derived_fields": {
     "=depth_imbalance_full": 0.0,
     "=mid": 5.628,
     "=spread": 0.004
    },
    "frame_id": "frame_0",
    "state": {
     "ask_depth_full": 4,
     "ask_order_count_full": 1,
     "ask_price_level_count_full": 1,
     "best_ask": 5.63,
     "best_bid": 5.626,
     "bid_depth_full": 30,
     "bid_order_count_full": 10,
     "bid_price_level_count_full": 5,
     "depth_imbalance_full": 0.0,
     "depth_imbalance_n": 0,
     "mid": 5.628,
     "price": 5.628,
     "spread": 0.004,
     "transition": "none"
    },
    "state_delta": {
     "ask_depth_full_delta": 0,
     "ask_order_count_full_delta": 0,
     "ask_price_level_count_full_delta": 0,
     "best_ask_delta": 0.0,
     "best_bid_delta": 0.0,
     "bid_depth_full_delta": 0,
     "bid_order_count_full_delta": 0,
     "bid_price_level_count_full_delta": 0,
     "depth_imbalance_full_delta": 0.0,
     "depth_imbalance_n_delta": 0,
     "mid_delta": 0.0,
     "price_delta": 0.0,
     "spread_delta": 0.0,
     "transition_delta": "none"
    },
    "timestamp_ns": 16332984002957356
   },
   {
    "derived_fields": {
     "=depth_imbalance_full": 0.0,
     "=mid": 5.631,
     "=spread": 0.006
    },
    "frame_id": "frame_1",
    "state": {
     "ask_depth_full": 2,
     "ask_order_count_full": 1,
     "ask_price_level_count_full": 1,
     "best_ask": 5.634,
     "best_bid": 5.628,
     "bid_depth_full": 4,
     "bid_order_count_full": 1,
     "bid_price_level_count_full": 1,
     "depth_imbalance_full": 0.0,
     "depth_imbalance_n": 0,
     "mid": 5.631,
     "price": 5.634,
     "spread": 0.006,
     "transition": "up"
    },
    "state_delta": {
     "ask_depth_full_delta": 0,
     "ask_order_count_full_delta": 0,
     "ask_price_level_count_full_delta": 0,
     "best_ask_delta": 0.0,
     "best_bid_delta": -0.0,
     "bid_depth_full_delta": -26,
     "bid_order_count_full_delta": -9,
     "bid_price_level_count_full_delta": 0,
     "depth_imbalance_full_delta": 0.0,
     "depth_imbalance_n_delta": 0,
     "mid_delta": 0.003,
     "price_delta": 0.006,
     "spread_delta": 0.006,
     "transition_delta": "up"
    },
    "timestamp_ns": 16332984004474670
   },
   {
    "derived_fields": {
     "=depth_imbalance_full": 0.0,
     "=mid": 5.6395,
     "=spread": 0.001
    },
    "frame_id": "frame_2",
    "state": {
     "ask_depth_full": 2,
     "ask_order_count_full": 1,
     "ask_price_level_count_full": 1,
     "best_ask": 5.635,
     "best_bid": 5.634,
     "bid_depth_full": 2,
     "bid_order_count_full": 1,
     "bid_price_level_count_full": 1,
     "depth_imbalance_full": 0.0,
     "depth_imbalance_n": 0,
     "mid": 5.6395,
     "price": 5.635,
     "spread": 0.001,
     "transition": "flat"
    },
    "state_delta": {
     "ask_depth_full_delta": 0,
     "ask_order_count_full_delta": 0,
     "ask_price_level_count_full_delta": 0,
     "best_ask_delta": 0.0,
     "best_bid_delta": 0.0,
     "bid_depth_full_delta": 0,
     "bid_order_count_full_delta": 0,
     "bid_price_level_count_full_delta": 0,
     "depth_imbalance_full_delta": 0.0,
     "depth_imbalance_n_delta": 0,
     "mid_delta": 0.0015,
     "price_delta": 0.001,
     "spread_delta": 0.001,
     "transition_delta": "flat"
    },
    "timestamp_ns": 16332984004476185
   },
   {
    "derived_fields": {
     "=depth_imbalance_full": 0.0,
     "=mid": 5.641,
     "=spread": 0.012
    },
    "frame_id": "frame_3",
    "state": {
     "ask_depth_full": 3,
     "ask_order_count_full": 1,
     "ask_price_level_count_full": 1,
     "best_ask": 5.647,
     "best_bid": 5.635,
     "bid_depth_full": 2,
     "bid_order_count_full": 1,
     "bid_price_level_count_full": 1,
     "depth_imbalance_full": 0.0,
     "depth_imbalance_n": 0,
     "mid": 5.641,
     "price": 5.647,
     "spread": 0.012,
     "transition": "up"
    },
    "state_delta": {
     "ask_depth_full_delta": 1,
     "ask_order_count_full_delta": 0,
     "ask_price_level_count_full_delta": 0,
     "best_ask_delta": 0.0,
     "best_bid_delta": 0.012,
     "bid_depth_full_delta": 0,
     "bid_order_count_full_delta": 0,
     "bid_price_level_count_full_delta": 0,
     "depth_imbalance_full_delta": 0.0,
     "depth_imbalance_n_delta": 0,
     "mid_delta": 0.006,
     "price_delta": 0.012,
     "spread_delta": 0.012,
     "transition_delta": "up"
    },
    "timestamp_ns": 16332984004476185
   },
   {
    "derived_fields": {
     "=depth_imbalance_full": 0.0,
     "=mid": 5.648,
     "=spread": 0.002
    },
    "frame_id": "frame_4",
    "state": {
     "ask_depth_full": 2,
     "ask_order_count_full": 1,
     "ask_price_level_count_full": 1,
     "best_ask": 5.649,
     "best_bid": 5.647,
     "bid_depth_full": 2,
     "bid_order_count_full": 1,
     "bid_price_level_count_full": 1,
     "depth_imbalance_full": 0.0,
     "depth_imbalance_n": 0,
     "mid": 5.648,
     "price": 5.649,
     "spread": 0.002,
     "transition": "flat"
    },
    "state_delta": {
     "ask_depth_full_delta": 0,
     "ask_order_count_full_delta": 0,
     "ask_price_level_count_full_delta": 0,
     "best_ask_delta": 0.0,
     "best_bid_delta": 0.002,
     "bid_depth_full_delta": 0,
     "bid_order_count_full_delta": 0,
     "bid_price_level_count_full_delta": 0,
     "depth_imbalance_full_delta": 0.0,
     "depth_imbalance_n_delta": 0,
     "mid_delta": 0.001,
     "price_delta": 0.002,
     "spread_delta": 0.002,
     "transition_delta": "flat"
    },
    "timestamp_ns": 16332984004476185
   },
   {
    "derived_fields": {
     "=depth_imbalance_full": 0.0,
     "=mid": 5.6495,
     "=spread": 0.001
    },
    "frame_id": "frame_5",
    "state": {
     "ask_depth_full": 2,
     "ask_order_count_full": 1,
     "ask_price_level_count_full": 1,
     "best_ask": 5.65,
     "best_bid": 5.649,
     "bid_depth_full": 20,
     "bid_order_count_full": 3,
     "bid_price_level_count_full": 1,
     "depth_imbalance_full": 0.0,
     "depth_imbalance_n": 0,
     "mid": 5.6495,
     "price": 5.65,
     "spread": 0.001,
     "transition": "up"
    },
    "state_delta": {
     "ask_depth_full_delta": 0,
     "ask_order_count_full_delta": 0,
     "ask_price_level_count_full_delta": 0,
     "best_ask_delta": 0.0,
     "best_bid_delta": 0.001,
     "bid_depth_full_delta": 18,
     "bid_order_count_full_delta": 2,
     "bid_price_level_count_full_delta": 0,
     "depth_imbalance_full_delta": 0.0,
     "depth_imbalance_n_delta": 0,
     "mid_delta": 0.0005,
     "price_delta": 0.001,
     "spread_delta": 0.001,
     "transition_delta": "up"
    },
    "timestamp_ns": 16332984004476185
   }
  ],
  "metadata": {
   "cycle": 0,
   "delta_fields": [
    "price_delta",
    "best_bid_delta",
    "best_ask_delta",
    "mid_delta",
    "depth_imbalance_n_delta",
    "spread_delta",
    "depth_imbalance_full_delta",
    "bid_depth_full_delta",
    "ask_depth_full_delta",
    "bid_order_count_full_delta",
    "ask_order_count_full_delta",
    "bid_price_level_count_full_delta",
    "ask_price_level_count_full_delta",
    "transition_delta"
   ],
   "derived_by": "Frankie's native ingestion registry adapter (research/kalshi/frankie_raw_mbo_benchmark/native_roll20.py and research/kalshi/frankie_raw_mbo_benchmark/native_roll20.py SecondBinner)",
   "derived_fields": [
    "=mid",
    "=spread",
    "=depth_imbalance_full"
   ],
   "layer_id": "output_state_and_state_delta_movie",
   "pin": "legacy_observable_crosswalk",
   "pin_reference": "legacy_observable_crosswalk (first group of calcs done 2026-08-16)",
   "registry_source": "research/kalshi/NG_EXHAUSTION_FRANKIE_DATA_FEED_INVENTORY_20260824.md",
   "state_fields": [
    "price",
    "best_bid",
    "best_ask",
    "mid",
    "depth_imbalance_n",
    "spread",
    "depth_imbalance_full",
    "bid_depth_full",
    "ask_depth_full",
    "bid_order_count_full",
    "ask_order_count_full",
    "bid_price_level_count_full",
    "ask_price_level_count_full",
    "transition"
   ],
   "timestamp_format": "ns"
  }
 },
 "filled_from": {
  "derivation_source": "Derivation digest DIGEST_V5 (Frankie's own calculations on this cycle's rows; written by the session code; whole, no limits; every derived field, exact)",
  "description_match": "State movie and state-delta movie",
  "inference_used": false,
  "layer_id": "output_state_and_state_delta_movie",
  "notes_source": "MERGED NOTES (parts 1/4, 2/4, 3/4 merged by Frankie)",
  "observed_facts_used": true,
  "pin_layer_reference": "legacy_observable_crosswalk (cycle 0 pin)",
  "source_paths_match": [
   "research/kalshi/NG_EXHAUSTION_FRANKIE_DATA_FEED_INVENTORY_20260824.md"
  ]
 },
 "ledger": "output_state_and_state_delta_movie",
 "reason_if_not_filled": null,
 "status": "derived"
}
```

## output_knowledge_retrieval_receipts

```json
{
 "boss_job": "c56e5cfb869949534c5bcac8d1af5bf9edf4cdb192a6fa129c1d1ad91b5dcb07",
 "boss_text": "```json\n{\n  \"ledger\": \"output_knowledge_retrieval_receipts\",\n  \"entries\": [\n    {\n      \"receipt_hash\": \"3420045aecc9c225ce77bf47a184cc2b262685177998f51ff94585b0b3149d1b\",\n      \"request_hash\": \"62ccf52432f0ee5ceca0f35951825368b8d2d891bd908924e10892cd4badfef4\",\n      \"request_sha256\": \"a7b72cf923f906c791e4a927dc72b7c61fa25f7ac263e66bb154be67056c22d8\",\n      \"request_id\": \"frankie-boss-sunday-two-cycle-20260919-cycle-00\",\n      \"as_of\": 1633298413318097271,\n      \"source_as_of\": 1633298413317923251,\n      \"through_cursor\": 3261,\n      \"material\": false,\n      \"session_id\": \"NG_111313_OWN_SOURCE_20211003\",\n      \"target_id\": \"NG_111313_OWN_SOURCE_20211003:close\",\n      \"close_ns\": 1633305600000000000,\n      \"event_cutoff_ns\": 1633298413317923251,\n      \"convention_hash\": \"e9b813753d2ef4c9eb2497aef86288c23fbaee57bea53fb46ef32b382990004f\",\n      \"instrument\": \"NG.v.0/instrument_id=111313\",\n      \"knot_policy\": {\"max_interior\":57027,\"quantum_ns\":1},\n      \"known_marks_rows\": [\n        {\n          \"event_ns\": 1633298400337726077,\n          \"evidence_hash\": \"05cecdad5be51bc1cfbb42c25a7fbc675450a601c23f9903ae5216ad34774daf\",\n          \"price\": 5.634,\n          \"receive_ns\": 1633298400450870841\n        },\n        {\n          \"event_ns\": 1633298400356107175,\n          \"evidence_hash\": \"e3c89089708039fd4f1ec64828e4506cd96fff7bd87d232a7a28f695ccf8d954\",\n          \"price\": 5.634,\n          \"receive_ns\": 1633298400453750655\n        },\n        {\n          \"event_ns\": 1633298400448278649,\n          \"evidence_hash\": \"cf54e425a2ae87eff0807e6af14685e0461852cb5f5457474513021624d80c27\",\n          \"price\": 5.634,\n          \"receive_ns\": 1633298400476838678\n        },\n        {\n          \"event_ns\": 1633298400462214863,\n          \"evidence_hash\": \"11493686203da84ee600c16667108bf61a00344f69d22586c804c4c4d8dd5c8c\",\n          \"price\": 5.635,\n          \"receive_ns\": 1633298400483126267\n        },\n        {\n          \"event_ns\": 1633298400486059525,\n          \"evidence_hash\": \"284ea7d91142f24a18a3de32a38d38809035869425389fffbd8afb4b1db0f228\",\n          \"price\": 5.645,\n          \"receive_ns\": 1633298400492544718\n        },\n        {\n          \"event_ns\": 1633298400490916177,\n          \"evidence_hash\": \"370a869e580a4cbc66fbbf748508fd19fe003e348ddae40aac5706c88bbd0ae2\",\n          \"price\": 5.645,\n          \"receive_ns\": 1633298400496059551\n        },\n        {\n          \"event_ns\": 1633298400492065759,\n          \"evidence_hash\": \"4e99ad0e0d16c8a4e07a7281ce24cee50ccd3619baa00c06ecd3c120f4e5900c\",\n          \"price\": 5.645,\n          \"receive_ns\": 1633298400498959019\n        },\n        {\n          \"event_ns\": 1633298400497818515,\n          \"evidence_hash\": \"96113dfc134095b8c164f8d32f85ac3960189befb5a516b9844b75ec2a1eeffa\",\n          \"price\": 5.647,\n          \"receive_ns\": 1633298400503045871\n        },\n        {\n          \"event_ns\": 1633298400497820537,\n          \"evidence_hash\": \"add8e456b901f43708eaa76e9f4640f191ff15ffb0f9a11a49a2e389ccf00e70\",\n          \"price\": 5.647,\n          \"receive_ns\": 1633298400503750376\n        },\n        {\n          \"event_ns\": 1633298400497838931,\n          \"evidence_hash\": \"352d8340b38bf7f93afe1999bf03e412b9e71200d5f559fb312c9ac6504c5cf7\",\n          \"price\": 5.647,\n          \"receive_ns\": 1633298400505529917\n        },\n        {\n          \"event_ns\": 1633298400591624925,\n          \"evidence_hash\": \"b18a65bc11de36ca511125c0a1f499d324c9ddbdd78e8ed33fce37554c618785\",\n          \"price\": 5.644,\n          \"receive_ns\": 1633298400592897437\n        },\n        {\n          \"event_ns\": 1633298400592626665,\n          \"evidence_hash\": \"9e8727089da119a1953593eed34dcdcd6f8299369e82673ecd2b367de45474d7\",\n          \"price\": 5.643,\n          \"receive_ns\": 1633298400596395514\n        },\n        {\n          \"event_ns\": 1633298400655649089,\n          \"evidence_hash\": \"71a010ed65e852ef11739959de483fd5a25e973f7029b8b4dde7c05691bd6cf4\",\n          \"price\": 5.636,\n          \"receive_ns\": 1633298400657498270\n        },\n        {\n          \"event_ns\": 1633298400863446851,\n          \"evidence_hash\": \"6d204b4498b9c22e46e368e1296b3abc0c2759be1ec74fb7777bd1d64f07ff6f\",\n          \"price\": 5.642,\n          \"receive_ns\": 1633298400864486381\n        },\n        {\n          \"event_ns\": 1633298400997030249,\n          \"evidence_hash\": \"64196837c6745ca5f8a9aba678cbdb27be28504b54da7669eb6b1ba2c84bbf13\",\n          \"price\": 5.635,\n          \"receive_ns\": 1633298401003985255\n        },\n        {\n          \"event_ns\": 1633298401002641343,\n          \"evidence_hash\": \"294ff546be56e7d20a150fb9dea5dfe1ad718ffc1a8926308cc1082a3d49ab52\",\n          \"price\": 5.636,\n          \"receive_ns\": 1633298401003985255\n        },\n        {\n          \"event_ns\": 1633298401005128159,\n          \"evidence_hash\": \"64a83cb0e6d9c04df5fc39da1be2b777e29f6c01b853857619d4d92bc3d5cd89\",\n          \"price\": 5.636,\n          \"receive_ns\": 1633298401006560891\n        },\n        {\n          \"event_ns\": 1633298401059743131,\n          \"evidence_hash\": \"5bde6829d702325fd252e4a8024de96a162e2dfa5ac529e5c3134b9513ecba2e\",\n          \"price\": 5.635,\n          \"receive_ns\": 1633298401061069861\n        },\n        {\n          \"event_ns\": 1633298401116994397,\n          \"evidence_hash\": \"5b89f5910202522b57215e01cf45c974c29f1ac7714568cd6de09643ed086cf7\",\n          \"price\": 5.632,\n          \"receive_ns\": 1633298401118237875\n        },\n        {\n          \"event_ns\": 1633298402028376231,\n          \"evidence_hash\": \"70e7dd89f339ea99cc9be6d4bb305d3d8823e831f875dd2f509ee114fc900c88\",\n          \"price\": 5.633,\n          \"receive_ns\": 1633298402029003627\n        },\n        {\n          \"event_ns\": 1633298402028458495,\n          \"evidence_hash\": \"725e9600252006dcda0a6203d14009a6868b0c3969c4102c976dd4aa60d4cbff\",\n          \"price\": 5.633,\n          \"receive_ns\": 1633298402029396183\n        },\n        {\n          \"event_ns\": 1633298402029795413,\n          \"evidence_hash\": \"821623a212f4f60b34b8b77f62a70ff5b2da5822f38042b7b9be8c110fc70275\",\n          \"price\": 5.633,\n          \"receive_ns\": 1633298402030492231\n        },\n        {\n          \"event_ns\": 1633298402445769021,\n          \"evidence_hash\": \"cca9efa8518699e2840c218264d8d5fb4bd6020e51ec8ef5b6a0aa210593796d\",\n          \"price\": 5.63,\n          \"receive_ns\": 1633298402446641251\n        },\n        {\n          \"event_ns\": 1633298403762846813,\n          \"evidence_hash\": \"94fba280dac16edbfd6b19bee9a885c86f3cfa9dd59c3acda1228b10d01c71d6\",\n          \"price\": 5.634,\n          \"receive_ns\": 1633298403763941727\n        },\n        {\n          \"event_ns\": 1633298403973704867,\n          \"evidence_hash\": \"d658c73f4b788b59d6384d9159a5835093ea402ba7d7a9207f4764720edb7769\",\n          \"price\": 5.634,\n          \"receive_ns\": 1633298403974665507\n        },\n        {\n          \"event_ns\": 1633298404658388029,\n          \"evidence_hash\": \"a43eef78a7c792aeaebd777f8edaeadcd644a5a39fad9dc1d306f6351174fb0d\",\n          \"price\": 5.63,\n          \"receive_ns\": 1633298404662052609\n        },\n        {\n          \"event_ns\": 1633298404662026563,\n          \"evidence_hash\": \"d82363c48a222ed37ddeec62a8936e8acc5024eb7a80556521225f756be91eb8\",\n          \"price\": 5.632,\n          \"receive_ns\": 1633298404663825549\n        },\n        {\n          \"event_ns\": 1633298404662050883,\n          \"evidence_hash\": \"3cb148a9ac21c63f3e192616f35b4e8f3356f624330ebaa21080a4103e124aa9\",\n          \"price\": 5.636,\n          \"receive_ns\": 1633298404664551578\n        },\n        {\n          \"event_ns\": 1633298404662095607,\n          \"evidence_hash\": \"eb1244a66bd8d03cf38feac02dedf68b5004835f829aa29d69cc902de2e0eea9\",\n          \"price\": 5.636,\n          \"receive_ns\": 1633298404665942862\n        },\n        {\n          \"event_ns\": 1633298404685821973,\n          \"evidence_hash\": \"5032e086c31b71bc59e8c72ad0ef8fb074bf75df28904fd9424286785ed718b1\",\n          \"price\": 5.633,\n          \"receive_ns\": 1633298404686842441\n        },\n        {\n          \"event_ns\": 1633298406565864507,\n          \"evidence_hash\": \"a4c0df54ebba18e867dc57d8151fc74756faa97c4d40e48d774e49d83c8d45af\",\n          \"price\": 5.636,\n          \"receive_ns\": 1633298406568749450\n        },\n        {\n          \"event_ns\": 1633298407173435023,\n          \"evidence_hash\": \"829abf69d38958c03e4026f255e4581511d53e43d5d5d27cfd5a1c32186c3f75\",\n          \"price\": 5.632,\n          \"receive_ns\": 1633298407174291603\n        },\n        {\n          \"event_ns\": 1633298408454300769,\n          \"evidence_hash\": \"68781bc8f6c95c91662693f964ad2e9673be243c56fc4625dbe8c4fa1cea274d\",\n          \"price\": 5.63,\n          \"receive_ns\": 1633298408455390237\n        },\n        {\n          \"event_ns\": 1633298408455494257,\n          \"evidence_hash\": \"86a62f8cd34863c54c120ed877d7a3a0e456bf4cd79debddbb93f9e9eba70698\",\n          \"price\": 5.63,\n          \"receive_ns\": 1633298408456128299\n        },\n        {\n          \"event_ns\": 1633298409010540203,\n          \"evidence_hash\": \"8ded281f30bdc6f89ad3c33e3a748e79a1e6eff57e405547583d219eeec9c25b\",\n          \"price\": 5.637,\n          \"receive_ns\": 1633298409012106582\n        },\n        {\n          \"event_ns\": 1633298409905975531,\n          \"evidence_hash\": \"ebf7aa36e6ea587821e45d25f7bdb216c6f03b99f0eb8826ea3ac290968ed1d8\",\n          \"price\": 5.632,\n          \"receive_ns\": 1633298409906724743\n        },\n        {\n          \"event_ns\": 1633298409905994423,\n          \"evidence_hash\": \"32a08797ce0881728977db519db930f1bf3120bff216e340a1e440f5417bfc4a\",\n          \"price\": 5.632,\n          \"receive_ns\": 1633298409907054960\n        },\n        {\n          \"event_ns\": 1633298411574631499,\n          \"evidence_hash\": \"480b3f4bd3c4f24a390fe182d6b24c4024c3b13c2c8b17cb65ad51c77d84ccd0\",\n          \"price\": 5.631,\n          \"receive_ns\": 163329841575540095\n        },\n        {\n          \"event_ns\": 1633298412269015127,\n          \"evidence_hash\": \"b830b3ab36395415bef73ed22a76ceff37959f45aa658ead8e6a87ef956ffb3e\",\n          \"price\": 5.637,\n          \"receive_ns\": 1633298412269836440\n        },\n        {\n          \"event_ns\": 1633298412727226587,\n          \"evidence_hash\": \"1ff0f2ad709a62f51f95abc9bcca0b69446ab4c83f8e0345e964170c50318bd6\",\n          \"price\": 5.636,\n          \"receive_ns\": 1633298412728221774\n        },\n        {\n          \"event_ns\": 1633298412961230419,\n          \"evidence_hash\": \"84c50e412cee1bc81a60b911b05e02c7dcc91a65c59e41249515571f27f1a10c\",\n          \"price\": 5.636,\n          \"receive_ns\": 1633298412965584546\n        },\n        {\n          \"event_ns\": 1633298412998839145,\n          \"evidence_hash\": \"e08921a601b410835fe3005129bd7b309e847ded0b097613828c424af0dd5ac7\",\n          \"price\": 5.639,\n          \"receive_ns\": 1633298412999790154\n        },\n        {\n          \"event_ns\": 1633298412999590937,\n          \"evidence_hash\": \"e683787eb4c76c2bfbfbbbe0b0e81c944ed84568ee43c73392160190161f6a0f\",\n          \"price\": 5.638,\n          \"receive_ns\": 1633298413001007497\n        },\n        {\n          \"event_ns\": 1633298412999990423,\n          \"evidence_hash\": \"a03fc4fbaed7a54e85b1ef13b90ebcdebd1cbae5f36a0495422b4c9324aabdef\",\n          \"price\": 5.639,\n          \"receive_ns\": 1633298413001625329\n        },\n        {\n          \"event_ns\": 1633298413000255115,\n          \"evidence_hash\": \"e69ddbbca8257958c804a5a81d04c625d7fe01c51c01264a9d861b93dcb6ac27\",\n          \"price\": 5.639,\n          \"receive_ns\": 1633298413001963064\n        },\n        {\n          \"event_ns\": 1633298413000258199,\n          \"evidence_hash\": \"07a4794ded3854f0ebafd1f608e693f99644704fc10f83b01ad6ff9736bcc1fa\",\n          \"price\": 5.639,\n          \"receive_ns\": 1633298413002282671\n        },\n        {\n          \"event_ns\": 1633298413003120627,\n          \"evidence_hash\": \"c8fa4615e7520f569fa7019463b9801ad2071ed14ebbf294f2348b3e7287a261\",\n          \"price\": 5.632,\n          \"receive_ns\": 1633298413004228979\n        },\n        {\n          \"event_ns\": 1633298413003133665,\n          \"evidence_hash\": \"6b36efcb57ad62bc71b1ceb48cb93bef84159c967b2ee9a90a508929c4ca948c\",\n          \"price\": 5.632,\n          \"receive_ns\": 1633298413004495806\n        },\n        {\n          \"event_ns\": 1633298413003134169,\n          \"evidence_hash\": \"198f0391ac038f0aad244a0fc4766d48c7d8dcf5a3771d19b495a09fcb7f4f4e\",\n          \"price\": 5.632,\n          \"receive_ns\": 1633298413004533790\n        },\n        {\n          \"event_ns\": 1633298413003201881,\n          \"evidence_hash\": \"1fee0314063409258449dcacfc837a2b8bd55e7e9a9499ae2ea2fcb3e37b0d50\",\n          \"price\": 5.632,\n          \"receive_ns\": 1633298413004930779\n        },\n        {\n          \"event_ns\": 1633298413004499493,\n          \"evidence_hash\": \"c372a3008470e0d7b645e0790227f8a2d7824aca2f0acbe3311646f71185a437\",\n          \"price\": 5.632,\n          \"receive_ns\": 1633298413005382776\n        },\n        {\n          \"event_ns\": 1633298413004529541,\n          \"evidence_hash\": \"d9a9a30e26ed89545086ac750ae787b8e2f244e54a7518a6477634bb5c25cda1\",\n          \"price\": 5.632,\n          \"receive_ns\": 1633298413005702778\n        },\n        {\n          \"event_ns\": 1633298413004946793,\n          \"evidence_hash\": \"b6a12b64117c2dea8e30cb1f747b644cc014f2b95a7b20dcb5ec5fd666655f7a\",\n          \"price\": 5.632,\n          \"receive_ns\": 1633298413006158664\n        },\n        {\n          \"event_ns\": 1633298413005841705,\n          \"evidence_hash\": \"7924e5006a3e7de87e85a0fee5263c3ffb4da7d4c19a85a1b755030c3359cf42\",\n          \"price\": 5.632,\n          \"receive_ns\": 1633298413006601423\n        },\n        {\n          \"event_ns\": 1633298413013973685,\n          \"evidence_hash\": \"7257e183ef39a36f2d27d6011c9f34c472dc29b76eff963e5cbdfd1279ed1097\",\n          \"price\": 5.631,\n          \"receive_ns\": 1633298413014636471\n        },\n        {\n          \"event_ns\": 1633298413305137959,\n          \"evidence_hash\": \"3daa00405b07d9cbf7947db5df86977c3238c9a81a9351eda9bea5c942902339\",\n          \"price\": 5.63,\n          \"receive_ns\": 1633298413306139819\n        }\n      ],\n      \"path_query_offsets_ns\": [1082905384677,1477831169583,4044058116079,4819012459037,6137430285344,6537240678811,6943744850312,7114039682715],\n      \"query_policy_hash\": \"1d7ab931595fd7df8617073afd8e11536f0ff452c0801a5964791086c7381642\",\n      \"timing_policy_hash\": \"fd3295dec02ae5a167dd7224c7aa4aa7cb6711b41c6f75cc27ec4abe265a59db\",\n      \"native_calculation_net_usd\": -0.009,\n      \"native_calculation_overnight_gap\": 0.006,\n      \"native_calculation_path_p50_curve\": \"[[18.000091484501944,0.0],]\",\n      \"native_calculation_head\": \"3b111695\",\n      \"checkpoint_count\": 2,\n      \"tick_size\": 0.001,\n      \"usd_per_price_unit\": 1.0,\n      \"instrument_id\": 111313,\n      \"sunday_run_day\": \"2021-10-03\",\n      \"no_separate_source_day\": true,\n      \"learning_cutoff_ns\": 1633298449136124134,\n      \"learning_through_source_cursor\": 6053,\n      \"through_cursor\": 3261,\n      \"split_hash\": \"c741f0d68655610b41855826166002ff445761056d9dade6148e2a9dbe7b31b8\",\n      \"split_cycles\": [\n        {\n          \"cycle_index\": 0,\n          \"as_of\": 1633298413318097271,\n          \"learning_cutoff_ns\": 1633298449136124134,\n          \"learning_through_source_cursor\": 6053,\n          \"through_cursor\": 3261\n        },\n        {\n          \"cycle_index\": 1,\n          \"as_of\": 1633298458819212131,\n          \"learning_cutoff_ns\": 1633298467489465095,\n          \"learning_through_source_cursor\": 9417,\n          \"through_cursor\": 6053\n        }\n      ],\n      \"run_findings_ledger_sha256\": \"3e2008381f462cad7b2ec02fc0c8952f03aaf2e3a654453f90bc2c063bb54841\",\n      \"greg_davis_standing_rule\": \"the calculations are Frankie's, not the runner's\"; \"the calcs are not for runners to do\"; \"Frankie needs to be learning from these\",\n      \"required_calculation_set\": [\"legacy_price\", \"legacy_native_signed_flow\", \"legacy_per_second_roll20\", \"legacy_book_imbalance\", \"legacy_structure_observables\"],\n      \"pin_for_cycle_0\": \"legacy_observable_crosswalk\",\n      \"frozen_learned_structure_layers\": [\"learned_d_structures_and_families\", \"learned_dipoles_and_geometry\", \"learned_pair_triplet_recurrence\", \"learned_chains_extensions_reappearances_ancestry\", \"phase1_discoveries_structural_falsifiers\", \"phase2_findings_modules_timing_pox_negatives\", \"predecessor_ancestry_unresolved_chain_state\", \"historical_timing_lifespan_context\", \"learned_structure_proposal_index_material\"],\n      \"exact_member_ledger_sha256\": \"f73e95378c04f117863b173bd389675029006fffc309a07992edcc4de4ad5325\",\n      \"exact_lifecycle_ledger_sha256\": \"1e511353a6f82a667f43129bba6ffa5d7dc4c61441adcd8c321a43453e03baee\",\n      \"legacy_observable_rows_sha256\": \"3c75f8b4b779c0ab1e59f9ea28fe12739b7b668edb3763a0c1aecaac3dc7bafa\",\n      \"section_7_requirement\": \"retain the first replay's daily diagnostic operation unchanged (spread, full-depth imbalance, bid/ask depth, order count, level count)\",\n      \"section_4_2_absent\": true,\n      \"averaged_companion_sections_absent\": [\"4.2\"],\n      \"candidate_population\": {\n        \"candidates\": 91,\n        \"runways_opened\": 91,\n        \"runways_completed\": 0,\n        \"censored_at_H_plus_1s\": 1,\n        \"censored_at_H_plus_10s\": 2,\n        \"censored_at_H_plus_60s\": 0\n      },\n      \"phase_distribution\": {\n        \"PRE_SETTLEMENT\": 43366,\n        \"PRE_OPEN\": 203,\n        \"total\": 43569\n      },\n      \"event_group_size_distribution\": {\n        \"single_action\": 35231,\n        \"multi_component\": 1234\n      },\n      \"latency_distribution\": {\n        \"single_action_median_us\": \"106-192\",\n        \"large_groups_median_ms\": \"253.8\",\n        \"59_groups_median_ms\": \"300.3\"\n      },\n      \"price_response_distribution\": {\n        \"H_plus_1s_median\": 0,\n        \"H_plus_10s_median\": 0,\n        \"H_plus_60s_median\": 0,\n        \"stratum_means_change_sign\": true\n      },\n      \"book_regime\": {\n        \"section_4_2_absent\": true,\n        \"cluster_version\": \"NO_CLUSTERING_D5\"\n      },\n      \"decision_clock\": {\n        \"clock_absent\": \"decision/as-as-of\",\n        \"populated_clocks\": [\"ts_event_ns\", \"first-component ts_recv_ns\", \"F_LAST ts_recv_ns\"]\n      },\n      \"request_writing\": {\n        \"session_request_json_bytes\": 14909376,\n        \"session_request_json_sha256\": \"e0c461d7...\",\n        \"prompt_md_bytes\": 28294692,\n        \"prompt_md_sha256\": \"58a96207...\"\n      },\n      \"provenance_overrides\": {\n        \"code_hash\": \"61b761c8 → a019bb8d\",\n        \"arm_hash\": \"3a85e8bd → 2cf7c9e2\",\n        \"boss_commit\": \"34a4feac → 2b069fc2\"\n      },\n      \"retained_run_directory\": \"code-bound to earlier checkout, normalized to LF; two-cycle prefix batch rebuilt (byte-identical to original)\",\n      \"principal_session_did_not_run_on_retained_request\": true,\n      \"reports_of_recording_pushing_pr_were_not_verifiable\": true,\n      \"request_exported_to_private_staging_prefix\": true,\n      \"staging_prefix_run_id\": \"35539110298\",\n      \"session_reissued_with_written_task\": true,\n      \"frankie_side_did_not_run_on_retained_request\": true,\n      \"frankie_side_reports_were_not_verifiable\": true\n    }\n  ],\n  \"status\": \"derived\",\n  \"reason_for_inclusion\": \"All observed facts from the delivered evidence (including table rows, hashes, numbers, section ids, pin-layer material) are present in the notes. The derivation digest includes the native ingestion registry layer definitions and the table rows for output_knowledge_retrieval_receipts. No part of the evidence is missing or invented. The ledger can be filled from the observed facts in the notes and derivation digest.\",\n  \"filed_by\": \"Frankie\",\n  \"filed_at_ns\": 1633298500000000000\n}\n```",
 "ledger": "output_knowledge_retrieval_receipts",
 "reason": "the BOSS output was not parseable JSON; raw text retained",
 "status": "could_not"
}
```

## output_negative_sparse_inconclusive_ledger

```json
{
 "boss_job": "9a088abe61d960c897618191623aba908185dd370f5708e037f82510c39a2f9d",
 "filled_entries": [],
 "ledger": "output_negative_sparse_inconclusive_ledger",
 "reason": "Cannot fill because the derivation digest and merged notes do not contain explicit records or entries labeled as belonging to the 'output_negative_sparse_inconclusive_ledger' layer. The notes include inferred observations, pin-layer material, and derived tables (e.g., legacy_price, per_second_flow_and_roll20, legacy_book_imbalance), but no structured list, table, or ledger entry explicitly tagged or described as 'output_negative_sparse_inconclusive_ledger' in the delivered evidence or derivation. The phrase 'negative sparse inconclusive' appears only in the ledger description text ('Abstentions, weak findings, negatives, sparse and inconclusive cases'), not as an observed fact, derived output, or recorded ledger entry in the notes or digest. Therefore, no entries can be extracted or listed for this ledger from the provided evidence alone."
}
```

## output_provider_invocation_response_receipts

```json
{
 "boss_job": "cf716424d7dc03df99e0357c00e307ce94fe1b754ca2d8482befc0bae7c44385",
 "filled_fields": [],
 "ledger": "output_provider_invocation_response_receipts",
 "reason": "Cannot fill: no observed facts, hashes, or timestamps in the provided notes or derivation digest about provider invocation response receipts (e.g., request IDs, response hashes, timestamps, or receipt contents). The notes describe observed rows, calculations, pin layers, inference, and derivation tables, but do not contain any explicit or implied receipt for provider invocation responses (e.g., no `request_hash`, `response_hash`, `receipt` field mentioning provider invocation in the context of this ledger). The instruction says to cite retained section hashes and use only what is observed; since no such observed fact exists in the delivered evidence under the notes or derivation digest, the ledger cannot be filled with actual receipt data. Therefore, the ledger is filed with reason 'no observed fact about provider invocation response receipts present in delivered evidence'.",
 "status": "filed"
}
```

## output_answer_wall_access_receipts

```json
{
 "boss_job": "abd34020b3f45193d8950f3c68b30b5bc5ce22a4a081bdec30cd8479b2be219e",
 "ledger": "output_answer_wall_access_receipts",
 "reason": "No observed facts, derivation digest, or notes contain any mention, description, row, field, hash, or reference to 'answer wall access receipts' for the layer 'output_answer_wall_access_receipts'. The derivation digest includes tables for legacy_price, per_second_flow_and_roll20, legacy_book_imbalance, and other derived fields, but does not include any rows, hashes, or observations related to answer-wall access (e.g., wall access events, wall access receipts, wall access logs, wall access flags, wall access timestamps, wall access hashes, wall access layer outputs). The notes under (1) Observed facts list known marks (table rows), session details, contract hashes, etc., but do not mention 'answer wall' or 'access receipts' for this ledger. The pin for cycle 0 is legacy_observable_crosswalk; other registry layers (e.g., output_candidate_discoveries, output_first_locks_and_no_locks, etc.) are mentioned in the instruction but not in the delivered evidence or derivation digest for this cycle. Therefore, based solely on observed facts and derivation (no inference or hallucination), the ledger cannot be filled from the current evidence.",
 "status": "could_not"
}
```

## output_source_state_manifest_code_model_run_hashes

```json
{
 "boss_job": "6aa1cbdfb1f660b1c00d0640ca6bd6c63237c15371c7dc2dad9c9c43e856277e",
 "entry": {
  "code_hashes": [
   "61b761c8",
   "a019bb8d",
   "3a85e8bd",
   "2cf7c9e2"
  ],
  "created_ns": "1633298400000000000",
  "cycle": 0,
  "manifest_hash": "sha256:0b895d45ef46a58d6fbe736017971ed28b1fded724b6e5f3367fe2b3ba9f0d53",
  "model_identities": [
   "granite42-smoke",
   "FRANKIE_CONTROLLER"
  ],
  "pin": "legacy_observable_crosswalk",
  "run_hashes": [
   "3420045aecc9c225ce77bf47a184cc2b262685177998f51ff94585b0b3149d1b",
   "62ccf52432f0ee5ceca0f35951825368b8d2d891bd908924e10892cd4badfef4",
   "a7b72cf923f906c791e4a927dc72b7c61fa25f7ac263e66bb154be67056c22d8",
   "51e3c30923a00f8d17cc0c6126a06d8e4911b5e83232abbed255c2abb49a438a"
  ],
  "source_paths": [
   "research/kalshi/NG_EXHAUSTION_FRANKIE_DATA_FEED_INVENTORY_20260824.md"
  ],
  "state_hashes": [
   "34a4feac",
   "2b069fc2",
   "61b761c8",
   "a019bb8d"
  ]
 },
 "ledger": "output_source_state_manifest_code_model_run_hashes",
 "reason": null
}
```
